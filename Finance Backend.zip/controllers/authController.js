import User from "../models/user.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const register = async (req,res) => {

  const {name,email,password,role} = req.body;

  const hashed = await bcrypt.hash(password,10);

  const user = await User.create({
    name,
    email,
    password:hashed,
    role
  });

  res.json(user);
};

export const login = async (req,res) => {

  const {email,password} = req.body;

  const user = await User.findOne({email});

  if(!user) return res.status(400).json({message:"User not found"});

  const match = await bcrypt.compare(password,user.password);

  if(!match) return res.status(400).json({message:"Invalid password"});

  const token = jwt.sign(
    {id:user._id, role:user.role},
    process.env.JWT_SECRET,
    {expiresIn:"1d"}
  );

  res.json({token});
};